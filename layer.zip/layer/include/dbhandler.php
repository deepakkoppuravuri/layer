<?php
class dbhandler{
    private $conn;
    //uses dbconnect.php and assigns db connection to $conn
    function __construct()
    {
        include_once dirname(__FILE__).'./dbconnect.php';
        $db=new database();
        $this->conn=$db->connect();
        if($this->conn==null)
        {
            echo 'error';
        }
    }
    //used for user registration
    function signup($username,$password)
    {
        $flag1=0;
        $stmt=$this->conn->prepare("SELECT email_id_u FROM users");
        $stmt->execute();
        $stmt->bind_result($usr);
        $stmt->store_result();
        while($stmt->fetch())
        {
            if($usr==$username)
            {
                $flag1=1;
                break;
            }
        }
        if($flag1==1)
        {
            //echo 'username already exists';
            return USER_ALREADY_EXISTS;
        }
        else{
            include_once dirname(__FILE__).'./passhashh.php';
            $hashedpass=passhash::hash($password);
            $apikey=passhash::generateapikey();
            $userid=passhash::genuserid($username);
            $stmt=$this->conn->prepare("INSERT INTO users(email_id_u,password,api_key,user_id) VALUES(?,?,?,?)");
            $stmt->bind_param("ssss",$username,$hashedpass,$apikey,$userid);
            $stmt->execute();
            return USER_CREATED;
        }
    }

    //user password verification
    function verifypass($username)
    {

        $stmt=$this->conn->prepare("select password from users where email_id_u=?");
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $stmt->bind_result($pass);
        $stmt->store_result();
        if($stmt->num_rows>0)
        {
            $stmt->fetch();
            return $pass;
        }
        else
        {
            return 10;
        }
    }

    //returns userid associted with email of user
    function getuserid($email)
    {
        $stmt=$this->conn->prepare("select user_id from users where email_id_u=?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        $stmt->fetch();
        return $res;
    }

    //returns api_key of user
    function getapi($email)
    {
        $stmt=$this->conn->prepare("select api_key from users where email_id_u=?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        $stmt->fetch();
        return $res;
    }

    //creates a row in book table after checking weather duplicate buk is present or not
    function createbook($publisher_id,$book_name,$category,$total_sets,$edition)
    {
        $stmt=$this->conn->prepare("select book_name from books where publisher_id=? and book_name=? and category=? and total_sets=? and edition=?");
        $stmt->bind_param("sssss",$publisher_id,$book_name,$category,$total_sets,$edition);
        $stmt->execute();
        $stmt->bind_result($bk);
        $stmt->store_result();
        while($stmt->fetch())
        {
            if($bk==$book_name)
            {
                return 9;
            }
        }
        $book_id=$this->genbookid();
        $stmt=$this->conn->prepare("insert into books(book_id,publisher_id,book_name,category,total_sets,edition) values(?,?,?,?,?,?)");
        $stmt->bind_param("ssssss",$book_id,$publisher_id,$book_name,$category,$total_sets,$edition);
        $stmt->execute();
        return 12;
    }
    //generated bookid
    function genbookid()
    {
        return substr(uniqid(rand(),true),0,6);
    }

    //returns bookdetails using bookid
    function bookdetails($bookid,$pubid)
    {
        $stmt=$this->conn->prepare("select book_id,book_name,category,total_sets,edition,status,image_path from books where book_id=? and publisher_id=?");
        $stmt->bind_param("ss",$bookid,$pubid);
        $stmt->execute();
        $res= $stmt->get_result();
        return $res;
    }
    //checks weather particular book is assioted with publisher or not
    function verifybooknpub($bookid,$pubid)
    {
        $stmt=$this->conn->prepare("select book_name from books where book_id=? and publisher_id=?");
        $stmt->bind_param("ss",$bookid,$pubid);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        if($stmt->num_rows<=0)
        {
            return 5;
        }
        return 6;
    }
    //updates the already present book or else returns book not assoiated with the publisher
    function updatebook($book_name,$category,$total_sets,$edition,$status,$book_id,$publisher_id)
    {
        $stmt=$this->conn->prepare("update  books set book_name=?,category=?,total_sets=?,edition=?,status=? where book_id=? and publisher_id=?");
        $stmt->bind_param("sssssss",$book_name,$category,$total_sets,$edition,$status,$book_id,$publisher_id);
        if($stmt->execute())
        {
            return 5;
        }
        return 6;
    }
    //new functions start from here as on 19/7/17
    //returns bookid
    function bookid($publisher_id,$book_name,$category,$total_sets,$edition)
    {
        $stmt=$this->conn->prepare("select book_id from books where publisher_id=? and book_name=? and category=? and total_sets=? and edition=?");
        $stmt->bind_param("sssss",$publisher_id,$book_name,$category,$total_sets,$edition);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        $stmt->fetch();
        return $res;
    }
    //adds or updateds keys in set_key table
    function addkey($set_id,$set_key)
    {
        $stmt1=$this->conn->prepare("select set_id from set_key where set_id=?");
        $stmt1->bind_param("s",$set_id);
        $stmt1->execute();
        $stmt1->bind_result($re);
        $stmt1->store_result();
        $stmt1->fetch();
        if($re==$set_id)
        {
            $stmt2=$this->conn->prepare("update set_key set set_key=? where set_id=?");
            $stmt2->bind_param("ss",$set_key,$set_id);
            if($stmt2->execute())
            {
                return 11;
            }
            return 9;
        }
        $stmt=$this->conn->prepare("insert into set_key(set_id,set_key) values(?,?)");
        $stmt->bind_param("ss",$set_id,$set_key);
        if($stmt->execute())
        {
            return 10;
        }
        else
        {
            return 9;
        }
    }
}
?>