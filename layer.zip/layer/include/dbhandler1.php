<?php
class dbhandler1{
    private $conn;
    function __construct()
    {
        include_once dirname(__FILE__).'./dbconnect.php';
        $db=new database();
        $this->conn=$db->connect();
        if($this->conn==null)
        {
            echo 'error';
        }
    }
    //used for publisher registration
    function signuppub($username,$password)
    {
        $flag1=0;
        $stmt=$this->conn->prepare("SELECT email_id_p FROM publishers");
        $stmt->execute();
        $stmt->bind_result($usr);
        $stmt->store_result();
        while($stmt->fetch())
        {
            if($usr==$username)
            {
                $flag1=1;
                break;
            }
        }
        if($flag1==1)
        {
            //echo 'username already exists';
            return USER_ALREADY_EXISTS;
        }
        else{
            include_once dirname(__FILE__).'./passhashh.php';
            $hashedpass=passhash::hash($password);
            $apikey=passhash::generateapikey();
            $pubid=passhash::genuserid($username);
            $stmt=$this->conn->prepare("INSERT INTO publishers(email_id_p,password,api_key,publisher_id) VALUES(?,?,?,?)");
            $stmt->bind_param("ssss",$username,$hashedpass,$apikey,$pubid);
            $stmt->execute();
            return USER_CREATED;
        }
    }
    //publisher password verification
    function verifypasspub($username)
    {

        $stmt=$this->conn->prepare("select password from publishers where email_id_p=?");
        $stmt->bind_param("s",$username);
        $stmt->execute();
        $stmt->bind_result($pass);
        $stmt->store_result();
        if($stmt->num_rows>0)
        {
            $stmt->fetch();
            return $pass;
        }
        else
        {
            return 10;
        }
    }
    //returns publishers id assocaiated with publisher email
    function getpubid($email)
    {
        $stmt=$this->conn->prepare("select publisher_id from publishers where email_id_p=?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        $stmt->fetch();
        return $res;
    }
    //returns api_key of publisher
    function getpubapi($email)
    {
        $stmt=$this->conn->prepare("select api_key from publishers where email_id_p=?");
        $stmt->bind_param("s",$email);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        $stmt->fetch();
        return $res;
    }
    //returns email of publisher using api_key
    function getpubemail($api)
    {
        $stmt=$this->conn->prepare("select email_id_p from publishers where api_key=?");
        $stmt->bind_param("s",$api);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        $stmt->fetch();
        return $res;
    }
    //used to verify api_key present in header of request
    function verifyapikey($api)
    {
        $stmt=$this->conn->prepare("select api_key from publishers");
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        while ($stmt->fetch())
        {
            if($res==$api)
            {
                $stmt1=$this->conn->prepare("select publisher_id from publishers where api_key=?");
                $stmt1->bind_param("s",$api);
                $stmt1->execute();
                $stmt1->bind_result($res1);
                $stmt1->store_result();
                $stmt1->fetch();
                return $res1;
            }
        }
        return 11;
    }
    //returns all the books associated with a particular publisher
    function pubbooks($pubid)
    {
        $stmt=$this->conn->prepare("select book_id from books where publisher_id=?");
        $stmt->bind_param("s",$pubid);
        $stmt->execute();
        $stmt->bind_result($res);
        $stmt->store_result();
        if($stmt->num_rows<=0)
        {
            return 8;
        }
        $result=array();
        $i=0;
        while($stmt->fetch())
        {
            $result[$i]=$res;
            $i++;
        }
        return $result;
    }

}
?>