<?php
//For database values and other constants.
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','');
define('DB_DATABASE','layer');
define('USER_ALREADY_EXISTS',0);
define('USER_CREATED',1);
define('NO_SUCH_USERNAME',1);
?>